
/**
 * Write a description of class DebitCard here.
 *
 * @author (22068192 Alish Bajracharya)
 * @version (1.0.0)
 */
public class DebitCard extends BankCard
{
    private int pinNumber;
    private int withdrawalAmount;
    private String dateOfWithdrawal;
    private boolean hasWithdrawn;
    // constructor with six parameters
     public DebitCard(int BalanceAmount, int cardid, String bankAccount, String issuerBank, String clientName, int pinNumber)
    {
        super(cardid,issuerBank,bankAccount,BalanceAmount);
        super.setclientName(clientName);
        this.pinNumber=pinNumber;
        this.hasWithdrawn=false;  
    }
    
    // acessor method of instance variable 
     public int getPinNumber()
    {
        return this.pinNumber;
    }
     public int getWithdrawalAmount()
    {
        return this.withdrawalAmount;
    }
     public String getDateOfWithdrawal()
    {
        return this.dateOfWithdrawal;
    }
     public boolean getHasWithdrawn()
    {
        return this.hasWithdrawn;
    }
    //  mutator method for withDrawalAmount
    
     public void setWithdrawalAmount(int withdrawalAmount)
    {
        this.withdrawalAmount=withdrawalAmount;
    }
    // withdraw method
     public void withdraw(int withdrawalAmount, int pinNumber, String dateOfWithdrawal)
    {
      if(this.getPinNumber()==pinNumber) 
        {
          if(withdrawalAmount < super.getBalanceAmount())
           {
            this.setWithdrawalAmount(withdrawalAmount);
            super.setBalanceAmount(super.getBalanceAmount()- withdrawalAmount);
            this.dateOfWithdrawal=dateOfWithdrawal;
            this.hasWithdrawn=true;
           }
        else
          {
            System.out.println("Your currennt balanceAmount is not sufficient.please try again.");
          }
      }
     else
      {
        System.out.println("pin number that you entered is invalid. please try again.");
      }
    }
    //displaying//
     public void display()
    {
        //calling method from super class BankCard
        super.display();
        {
            if(this.hasWithdrawn==true)//condition for checking haswithdrawn true
            {
              System.out.println("Your Debit card pin number is "+ this.pinNumber);
              System.out.println("The date of your withdrawing is "+this.dateOfWithdrawal);
              System.out.println("Your withdrawn amount is "+ this.withdrawalAmount);
            }
            else
            {
              System.out.println("withdrawal has not been made yet.");
            }
        }
    }
}