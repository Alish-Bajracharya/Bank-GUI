/**
 * Write a description of class BankCard here.
 *
 * @author (22068192 Alish Bajracharya)
 * @version (1.0.0)
 */
public class BankCard
{
    private int cardId;
    private String clientName;
    private String issuerBank;
    private String bankAccount;
    private int balanceAmount;

    public BankCard(int cardid, String bankAccount, String issuerBank, int BalanceAmount){
        this.balanceAmount = BalanceAmount;
        this.cardId = cardid;
        this.bankAccount = bankAccount;
        this.issuerBank = issuerBank;
        this.clientName = "";
    }  
    //Getter method//
    public int getcardId()
    {
        return this.cardId;
    }

    public String getclientName()
    {
        return this.clientName;
    }

    public String getissuerBank()
    {
        return this.issuerBank;
    }

    public String getbankAccount()
    {
        return this.bankAccount;  
    }

    public int getbalanceAmount()
    {
        return this.balanceAmount;
    }
    //mutator method//
    public void setclientName( String clientName)
    {
        this.clientName = clientName;
    }

    public void setBalanceAmount(int BalanceAmount)
    {
        this.balanceAmount = balanceAmount;
    }
    //displaying //
    public void display()
    {   
        if (clientName.equals("")) 
        {
            System.out.println("Client name has not been set.");
        } 
        else
        {
            System.out.println("Card ID: " +this. cardId);
            System.out.println("Client name: " +this. clientName);
            System.out.println("Issuer bank: " +this. issuerBank);
            System.out.println("Bank account: " + this.bankAccount);
            System.out.println("Balance amount: " + this.balanceAmount);
        }
    }
}