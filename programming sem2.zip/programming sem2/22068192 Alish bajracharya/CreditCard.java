
/**
 * Write a description of class CreditCard here.
 *
 * @author (22068192 Alish Bajrcahrya)
 * @version (1.0.0)
 */
public class CreditCard extends BankCard
{
    private int cvcNumber;
    private double creditLimit;
    private double interestRate;
    private String expirationDate;
    private int gracePeriod;
    private boolean isGranted;
    //creating constructor with 8 parameters//
    public CreditCard(int cardId, String clientName, String issuerBank, String bankAccount, int balanceAmount, int CVCNumber,
    double interestRate, String expirationDate) 
    {
        super(cardId,issuerBank,bankAccount,balanceAmount);
        //calling constructer of super class
        super.setclientName(clientName);
        this.cvcNumber = cvcNumber;
        this.interestRate = interestRate;
        this.expirationDate = expirationDate;
        this.isGranted = false;
    }
    //Accessor method//
    public int getCVCNumber() 
    {
        return this.cvcNumber;
    }

    public double getCreditLimit() 
    {
        return this.creditLimit;
    }

    public double getInterestRate() 
    {
        return this.interestRate;
    }

    public String getExpirationDate() 
    {
        return this.expirationDate;
    }

    public int getGracePeriod()
    {
        return this.gracePeriod;
    }

    public boolean getIsGranted()
    {
        return this.isGranted;
    }
    //setter method with parameter//
    public void setCreditLimit(int CreditLimit, int GracePeriod)
    {
        if (CreditLimit <= 2.5 * super.getbalanceAmount()) 
        {
            this.creditLimit = CreditLimit;
            this.gracePeriod = GracePeriod;
            this.isGranted = true;
        } else {
            System.out.println("Credit cannot be issued.");
        }
    }
    //creating cancelCredit method//
    public void cancelCreditCard()
    {
        this.cvcNumber = 0;
        this.creditLimit = 0;
        this.gracePeriod = 0;
        this.isGranted = false;
    }
    //displaying//
    public void display()
    { 
        System.out.println("Interest Rate: " + this.interestRate);
        System.out.println("Expiration Date: " + this.expirationDate);
        if (isGranted==true) 
        {
            super.display();//calling display method from super class
            System.out.println("Cvc Number: " + this.cvcNumber);
            System.out.println("Credit Limit: " +this. creditLimit);
            System.out.println("Grace Period: " + this.gracePeriod);
        }
    }
}

