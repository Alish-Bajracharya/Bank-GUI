
/**
 * Write a description of class BankGUI here.
 *
 * @author 
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;

public class BankGUI extends JFrame implements ActionListener{
    private ArrayList<BankCard> bankcards = new ArrayList<BankCard>();
    private JLabel cardIdLabel, clientNameLabel, issuerBankLabel, bankAccountLabel, balanceAmountLabel, 
    pinNumberLabel,withdrawalAmountLabel, cvcNumberLabel, creditLimitLabel, interestRateLabel,
    gracePeriodLabel, withdrawalLabel, expirationLabel;
    private JTextField cardIdField, clientNameField, issuerBankField, bankAccountField,
    balanceAmountField, pinNumberField, withdrawalAmountField, cvcNumberField,
    creditLimitField, interestRateField, gracePeriodField;
    private JButton debitCardButton, creditCardButton, withdrawalButton,setCreditLimitButton,
    cancelCreditCardButton, displayButton, clearButton;
    private JComboBox withdrawalDate, withdrawalYearsCombo, withdrawalMonthsCombo, withdrawalDaysCombo,
    expirationDate, expirationYearsCombo, expirationMonthsCombo, expirationDaysCombo;

    public BankGUI(){
        //creating arraylist

        // creating object of class: JFrame and Set frame and layout
        JFrame frame = new JFrame();
        frame.setSize(750, 500);
        frame.setLayout(null);

        //creating GUI components
        cardIdLabel = new JLabel("Card ID:");
        cardIdField = new JTextField();
        clientNameLabel = new JLabel("Client Name:");
        clientNameField = new JTextField();
        issuerBankLabel = new JLabel("Issuer Bank:");
        issuerBankField = new JTextField();
        bankAccountLabel = new JLabel("Bank Account:");
        bankAccountField = new JTextField();
        balanceAmountLabel = new JLabel("Balance Amount:");
        balanceAmountField = new JTextField();
        pinNumberLabel = new JLabel("PIN Number:");
        pinNumberField = new JTextField();
        withdrawalAmountLabel = new JLabel("Withdrawal Amount:");
        withdrawalAmountField = new JTextField();
        cvcNumberLabel = new JLabel("CVC Number:");
        cvcNumberField = new JTextField();
        creditLimitLabel = new JLabel("Credit Limit:");
        creditLimitField = new JTextField();
        interestRateLabel = new JLabel("Interest Rate:");
        interestRateField = new JTextField();
        gracePeriodLabel = new JLabel("Grace Period:");
        gracePeriodField = new JTextField();
        withdrawalLabel = new JLabel("Withdrawal Date:");
        expirationLabel = new JLabel("Expiration Date:");

        //creating JComboBox
        JComboBox comboBox = new JComboBox();
        String[] withdrawalYears = {"2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035"};
        withdrawalYearsCombo = new JComboBox(withdrawalYears);
        String[] withdrawalMonths = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        withdrawalMonthsCombo = new JComboBox(withdrawalMonths);
        String[] withdrawalDays = new String[31];
        for (int i = 0; i < 31; i++) {
            withdrawalDays[i] = Integer.toString(i+1);
        }
        withdrawalDaysCombo = new JComboBox<>(withdrawalDays);

        String[] expirationYears = {"2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035"};
        expirationYearsCombo = new JComboBox(expirationYears);
        String[] expirationMonths = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        expirationMonthsCombo = new JComboBox(expirationMonths);
        String[] expirationDays = new String[31];
        for (int i = 0; i < 31; i++) {
            expirationDays[i] = Integer.toString(i+1);
        }
        expirationDaysCombo = new JComboBox<>(expirationDays);

        //creating Jbuttons 
        debitCardButton = new JButton("Add Debit Card");
        creditCardButton = new JButton("Add Credit Card");
        withdrawalButton = new JButton("Withdraw from Debit Card");
        setCreditLimitButton = new JButton("Set Credit Limit");
        cancelCreditCardButton = new JButton("Cancel Credit Card");
        displayButton = new JButton("Display");
        clearButton = new JButton("Clear");

        //setting bounds of components
        cardIdLabel.setBounds(20, 30, 50, 30);
        cardIdField.setBounds(122, 30, 100, 30);
        clientNameLabel.setBounds(20, 85, 75, 30);
        clientNameField.setBounds(122, 85, 210, 30);
        issuerBankLabel.setBounds(420, 85, 70, 30);
        issuerBankField.setBounds(122, 135, 220, 30);
        bankAccountLabel.setBounds(20, 135, 85, 30);
        bankAccountField.setBounds(540,85, 180, 30);
        balanceAmountLabel.setBounds(420,135, 100, 30);
        balanceAmountField.setBounds(540, 135, 180, 30);
        pinNumberLabel.setBounds(20, 185, 150, 30);
        pinNumberField.setBounds(122, 185, 120, 30);
        withdrawalAmountLabel.setBounds(160, 290, 130, 30);
        withdrawalAmountField.setBounds(275, 290, 100, 30);
        cvcNumberLabel.setBounds(505, 190, 100, 30);
        cvcNumberField.setBounds(590, 190, 130, 30);
        creditLimitLabel.setBounds(495, 345, 100, 30);
        creditLimitField.setBounds(580, 345, 140, 30);
        interestRateLabel.setBounds(20, 235, 80, 30);
        interestRateField.setBounds(122, 235, 150, 30);
        gracePeriodLabel.setBounds(250, 345, 100, 30);
        gracePeriodField.setBounds(350, 345, 110, 30);
        withdrawalLabel.setBounds(380, 290, 100, 30);
        withdrawalYearsCombo.setBounds(485, 290, 69, 32);
        withdrawalMonthsCombo.setBounds(560, 290, 100, 32);
        withdrawalDaysCombo.setBounds(665, 290, 55, 32);
        expirationLabel.setBounds(385, 230 , 100, 32);
        expirationYearsCombo.setBounds(485, 235, 69, 32);
        expirationMonthsCombo.setBounds(560, 235, 100, 32);
        expirationDaysCombo.setBounds(665, 235, 55, 32);
        debitCardButton.setBounds(290, 185, 180, 32);
        creditCardButton.setBounds(20, 290, 130, 32);
        withdrawalButton.setBounds(20, 345, 195, 32);
        setCreditLimitButton.setBounds(20, 400, 135, 32);
        cancelCreditCardButton.setBounds(570, 400, 150, 32);
        displayButton.setBounds(215, 400, 120, 32);
        clearButton.setBounds(400, 400, 120, 32);

        debitCardButton.addActionListener(this);
        creditCardButton.addActionListener(this);
        withdrawalButton.addActionListener(this);
        setCreditLimitButton.addActionListener(this);
        cancelCreditCardButton.addActionListener(this);
        displayButton.addActionListener(this);
        clearButton.addActionListener(this);

        // Adding GUI components to frame
        frame.add(cardIdLabel);
        frame.add(cardIdField);
        frame.add(clientNameLabel);
        frame.add(clientNameField);
        frame.add(issuerBankLabel);
        frame.add(issuerBankField);
        frame.add(bankAccountLabel);
        frame.add(bankAccountField);
        frame.add(balanceAmountLabel);
        frame.add(balanceAmountField);
        frame.add(pinNumberLabel);
        frame.add(pinNumberField);
        frame.add(withdrawalAmountLabel);
        frame.add(withdrawalAmountField);
        frame.add(cvcNumberLabel);
        frame.add(cvcNumberField);
        frame.add(creditLimitLabel);
        frame.add(creditLimitField);
        frame.add(interestRateLabel);
        frame.add(interestRateField);
        frame.add(gracePeriodLabel);
        frame.add(gracePeriodField);
        frame.add(withdrawalLabel);
        frame.add(withdrawalYearsCombo);
        frame.add(withdrawalMonthsCombo);
        frame.add(withdrawalDaysCombo);
        frame.add(expirationLabel);
        frame.add(expirationYearsCombo);
        frame.add(expirationMonthsCombo);
        frame.add(expirationDaysCombo);
        frame.add(debitCardButton);
        frame.add(creditCardButton);
        frame.add(withdrawalButton);
        frame.add(setCreditLimitButton);
        frame.add(cancelCreditCardButton);
        frame.add(displayButton);
        frame.add(clearButton);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() ==debitCardButton){
            try{
                // Get values from GUI text fields
                int balanceAmount = Integer.parseInt(balanceAmountField.getText());
                int cardId = Integer.parseInt(cardIdField.getText());
                String bankAccount = bankAccountField.getText();
                String issuerBank = issuerBankField.getText();
                String clientName = clientNameField.getText();
                int pinNumber = Integer.parseInt(pinNumberField.getText());
                boolean add = false;
                for(BankCard card: bankcards){
                    if (card instanceof DebitCard){
                        DebitCard debitCard = (DebitCard) card;
                        if(debitCard.getcardId() ==cardId){
                            System.out.print("Card already Exist");
                            add = true;
                            break;
                        }
                        else{
                            add = false;
                        }
                    }
                }
                if(!add){
                    // Create new DebitCard object and add it to ArrayList
                    DebitCard debitCard = new DebitCard(balanceAmount, cardId, bankAccount, issuerBank, clientName, pinNumber);
                    bankcards.add(debitCard);
                    JOptionPane.showMessageDialog(this, "Debit Card added successfully");
                }
            }
            // Display success message
            catch(Exception a){
                JOptionPane.showMessageDialog(null,"Fill the correct details","Error",JOptionPane.ERROR_MESSAGE);
            }
        }
        if(e.getSource() ==creditCardButton){
            try{
                int cardId = Integer.parseInt(cardIdField.getText());
                String clientName = clientNameField.getText();
                String issuerBank = issuerBankField.getText();
                String bankAccount = bankAccountField.getText();
                int balanceAmount = Integer.parseInt(balanceAmountField.getText());
                int cvcNumber = Integer.parseInt(cvcNumberField.getText());
                double interestRate = Double.parseDouble(interestRateField.getText());
                String expirationYearsCombo1 = expirationYearsCombo.getSelectedItem().toString();
                String expirationMonthsCombo1 = expirationMonthsCombo.getSelectedItem().toString();
                String expirationDaysCombo1 = expirationDaysCombo.getSelectedItem().toString();
                String expirationDate = expirationYearsCombo1 +"/" + expirationMonthsCombo1 + "/" + expirationDaysCombo1;
                boolean add = false;
                for(BankCard card: bankcards){
                    if (card instanceof CreditCard){
                        CreditCard creditCard = (CreditCard) card;
                        if(creditCard.getcardId() ==cardId){
                            System.out.print("Card already Exist");
                            add = true;
                            break;
                        }
                        else{
                            add = false;
                        }
                    }
                }
                if(!add){
                    //create new creditcard object
                    CreditCard creditCard = new CreditCard(cardId, clientName, issuerBank, bankAccount, balanceAmount, cvcNumber, interestRate, expirationDate);
                    //added to arraylist of bankcard class
                    bankcards.add(creditCard);
                    JOptionPane.showMessageDialog(this, "Credit Card added successfully");
                }
            }
            catch(Exception a){
                JOptionPane.showMessageDialog(null,"Fill the correct details","Error",JOptionPane.ERROR_MESSAGE);
            }
        }
        if(e.getSource() ==withdrawalButton){
            try{
                int cardId = Integer.parseInt(cardIdField.getText());
                int withdrawalAmount = Integer.parseInt(withdrawalAmountField.getText());
                int pinNumber = Integer.parseInt(pinNumberField.getText());
                String withdrawalYearsCombo1 = withdrawalYearsCombo.getSelectedItem().toString();
                String withdrawalMonthsCombo1 = withdrawalMonthsCombo.getSelectedItem().toString();
                String withdrawalDaysCombo1 = withdrawalDaysCombo.getSelectedItem().toString();
                String withdrawalDate = withdrawalYearsCombo1 +"/" + withdrawalMonthsCombo1 + "/" +withdrawalDaysCombo1;
                // found a matching DebitCard, withdraw the amount
                for(BankCard card: bankcards){
                    if(card instanceof DebitCard){
                        DebitCard debitCard = (DebitCard) card;
                        if(debitCard.getcardId() == cardId){
                            debitCard.withdraw(withdrawalAmount, pinNumber, withdrawalDate);
                            JOptionPane.showMessageDialog(this, "Withdrawal successful.");
                        }
                    }
                }   
            } 
            catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(null, "Fill the Details", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        if(e.getSource() ==setCreditLimitButton){
            try{
                int cardId = Integer.parseInt(cardIdField.getText());
                int CreditLimit = Integer.parseInt(creditLimitField.getText());
                int GracePeriod = Integer.parseInt(gracePeriodField.getText());
                for(BankCard card: bankcards){
                    if(card instanceof CreditCard){
                        CreditCard creditCard = (CreditCard) card;
                        if(creditCard.getcardId() == cardId){
                            // Display a success message
                            JOptionPane.showMessageDialog(this, "Credit limit and grace period updated for card ID: " + cardId);
                        }
                    }
                }
            }
            catch (NumberFormatException ex) {
                // Display an error message if the user enters invalid input
                JOptionPane.showMessageDialog(null, "Please enter valid numbers for new credit limit and grace period.");
            }
        }
        if(e.getSource() ==cancelCreditCardButton){
            try{
                int cardId = Integer.parseInt(cardIdField.getText());
                boolean cardCancelled = false;
                // Loop through the list of BankCards to find a CreditCard with the matching card ID
                for (BankCard card : bankcards){
                    if (card.getcardId() == cardId){
                        if (card instanceof CreditCard){
                            // Cast the BankCard object as a CreditCard object
                            CreditCard creditCard = (CreditCard) card;
                            creditCard.cancelCreditCard();
                            cardCancelled = true;
                            if (cardCancelled) {
                                JOptionPane.showMessageDialog(this, "Credit Card with ID " + cardId + " has been cancelled.", "Card Cancelled", JOptionPane.INFORMATION_MESSAGE);
                            }
                        }
                    }
                }
            }

            catch(Exception a){
                // Display appropriate message in dialog box based on whether the card was cancelled or not
                JOptionPane.showMessageDialog(null, "Credit Card with ID " + cardIdField + " not found.", "Card Not Found", JOptionPane.ERROR_MESSAGE);
            }
        }
        if(e.getSource() ==displayButton){
            for(BankCard card : bankcards){
                if(card instanceof DebitCard){
                    card.display();
                }
            }
            for(BankCard card : bankcards){
                if(card instanceof CreditCard){
                    card.display();
                }
            }
        }
        if(e.getSource() ==clearButton){
            for(BankCard card : bankcards){
                // Clear text fields
                balanceAmountField.setText("");
                cardIdField.setText("");
                bankAccountField.setText("");
                issuerBankField.setText("");
                clientNameField.setText("");
                pinNumberField.setText("");
                cvcNumberField.setText("");
                interestRateField.setText("");
                expirationDate.setSelectedIndex(0);
                withdrawalAmountField.setText("");
                withdrawalDate.setSelectedIndex(0);
                creditLimitField.setText("");
                gracePeriodField.setText("");
            }
        }
    }

    public static void main (String[] args){
        new BankGUI();
    }
}